-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2025 at 06:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cngpump`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmin`
--

CREATE TABLE `addmin` (
  `Id` int(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addmin`
--

INSERT INTO `addmin` (`Id`, `Email`, `Password`) VALUES
(1, 'u@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `UserId` int(20) NOT NULL,
  `UserName` varchar(40) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `VehicalName` varchar(40) NOT NULL,
  `PumpName` varchar(40) NOT NULL,
  `PumpId` int(20) NOT NULL,
  `CngRequired` int(70) NOT NULL,
  `PaymentMode` varchar(45) NOT NULL,
  `Mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`UserId`, `UserName`, `Email`, `VehicalName`, `PumpName`, `PumpId`, `CngRequired`, `PaymentMode`, `Mobile`) VALUES
(1, 'd', 'u@gmail.com', 'audi', 'c', 2, 2, 'Online', '8010819643'),
(2, 'Utkarsh', 'u@gmail.com', 'j', 'nashik', 1, 9, 'offline', '9106202026'),
(3, 'Utkarsh', 'u@gmail.com', 'audi', 'nashik', 1, 500, 'online', '9106202026'),
(4, 'Utkarsh', 'u@gmail.com', 'Thar', 'nashik', 1, 200, 'offline', '9106202026'),
(7, 'Utkarsh', 'u@gmail.com', 'BMW', 'Nayra', 1, 500, 'online', '9106202026'),
(8, 'Utkarsh', 'u@gmail.com', 'Nexon', 'HP CNG', 4, 50, 'online', '9106202026'),
(9, 'Utkarsh', 'u@gmail.com', 'Nexon', 'Nayra', 1, 50, 'online', '8767006153');

-- --------------------------------------------------------

--
-- Table structure for table `cng`
--

CREATE TABLE `cng` (
  `Id` int(20) NOT NULL,
  `Pump name` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `Tal` varchar(30) NOT NULL,
  `Dist` varchar(30) NOT NULL,
  `Open Time` varchar(30) NOT NULL,
  `Close Time` varchar(30) NOT NULL,
  `Mobile` varchar(30) NOT NULL,
  `Latitude` varchar(30) NOT NULL,
  `Longitude` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Cng` int(20) NOT NULL,
  `Status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cng`
--

INSERT INTO `cng` (`Id`, `Pump name`, `Address`, `City`, `Tal`, `Dist`, `Open Time`, `Close Time`, `Mobile`, `Latitude`, `Longitude`, `Password`, `Cng`, `Status`) VALUES
(1, 'Nayra', 'nashik', 'nashik', 'nashik', 'nashik', '6:00 Am', '6:00 Pm', '8767006153', '18.788 N', '17.99 W', '1234', 1150, 'Approved'),
(4, 'HP CNG', 'pune', 'pune', 'pune', 'pune', '6:00 Am', '6.00 Pm', '9106202026', '23.00N', '14.98W', '1234', 972, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Id` int(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `PumpId` int(3) NOT NULL,
  `City` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Id`, `Name`, `Email`, `Password`, `PumpId`, `City`) VALUES
(1, 'utkarsh', 'u@gmail.com', '12345', 2, 'ghatghar'),
(2, 'Viraj', 'viraj@gmail.com', '12345', 1, 'Nandurbar');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Mobile` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `Name`, `Email`, `Mobile`, `Password`, `City`) VALUES
(1, 'Utkarsh', 'u@gmail.com', '8767006153', '1234', 'sangmaner'),
(2, 'Hemant', 'h@gmail.com', '9106202026', '1234', 'lahor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addmin`
--
ALTER TABLE `addmin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `cng`
--
ALTER TABLE `cng`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addmin`
--
ALTER TABLE `addmin`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `UserId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cng`
--
ALTER TABLE `cng`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
